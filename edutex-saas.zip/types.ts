export enum AgentStatus {
  IDLE = 'IDLE',
  THINKING = 'THINKING',
  WORKING = 'WORKING',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}

export interface Agent {
  id: string;
  name: string;
  role: string;
  description: string;
  status: AgentStatus;
  icon: string; // Icon name
}

export interface Question {
  id: string;
  content: string; // The LaTeX content
  solution: string; // The LaTeX solution
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Olympiad';
  points: number;
  type: 'Algebra' | 'Geometry' | 'Calculus' | 'Physics';
  tags: string[];
}

export interface Exam {
  id: string;
  title: string;
  subject: string;
  gradeLevel: string;
  durationMinutes: number;
  questions: Question[];
  createdAt: string;
  difficulty: number; // 0-100
}

export interface GenerationParams {
  topic: string;
  gradeLevel: string;
  difficulty: number; // 1-5 slider
  questionCount: number;
  includeSolutions: boolean;
}
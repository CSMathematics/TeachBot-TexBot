import React from 'react';
import { Agent, AgentStatus } from '../types';
import { Bot, FileText, Brain, CheckCircle, Loader2 } from 'lucide-react';
import { Card, CardContent } from './ui';
import { cn } from '../lib/utils';

interface AgentCardProps {
  agent: Agent;
}

const AgentCard: React.FC<AgentCardProps> = ({ agent }) => {
  const getIcon = () => {
    switch (agent.id) {
      case 'architect': return <Brain className="w-5 h-5" />;
      case 'generator': return <Bot className="w-5 h-5" />;
      case 'validator': return <CheckCircle className="w-5 h-5" />;
      case 'typesetter': return <FileText className="w-5 h-5" />;
      default: return <Bot className="w-5 h-5" />;
    }
  };

  const isWorking = agent.status === AgentStatus.WORKING;
  const isCompleted = agent.status === AgentStatus.COMPLETED;
  const isError = agent.status === AgentStatus.ERROR;

  return (
    <Card className={cn(
      "transition-all duration-300",
      isWorking && "border-primary shadow-md ring-1 ring-primary/20",
      isCompleted && "bg-muted/50 opacity-80",
      isError && "border-destructive/50 bg-destructive/10"
    )}>
      <CardContent className="p-4 flex items-center space-x-4">
        <div className={cn(
          "p-2 rounded-full border",
          isWorking ? "bg-primary/10 border-primary/20 text-primary" : "bg-background border-border text-muted-foreground",
          isCompleted && "bg-green-100 border-green-200 text-green-700 dark:bg-green-900/20 dark:border-green-800 dark:text-green-400"
        )}>
          {getIcon()}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold leading-none">{agent.name}</h3>
            {isWorking && <Loader2 className="w-3 h-3 animate-spin text-primary" />}
            {isCompleted && <CheckCircle className="w-3 h-3 text-green-600 dark:text-green-400" />}
          </div>
          <p className="text-xs text-muted-foreground mt-1 truncate">
            {isWorking ? "Processing..." : agent.role}
          </p>
        </div>
      </CardContent>
      
      {/* Progress Bar for Working State */}
      {isWorking && (
        <div className="h-0.5 w-full bg-primary/10 overflow-hidden rounded-b-lg">
          <div className="h-full bg-primary animate-accordion-down w-1/3 mx-auto rounded-full"></div> 
        </div>
      )}
    </Card>
  );
};

export default AgentCard;
import React from 'react';
import { LayoutDashboard, PenTool, BookOpen, Settings, Library, LogOut, ChevronRight } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../lib/utils';
import { Button } from './ui';

const Sidebar: React.FC = () => {
  const location = useLocation();

  const navItems = [
    { icon: <LayoutDashboard size={18} />, label: 'Dashboard', path: '/' },
    { icon: <PenTool size={18} />, label: 'Exam Creator', path: '/create' },
    { icon: <Library size={18} />, label: 'My Library', path: '/library' },
    { icon: <BookOpen size={18} />, label: 'Curriculum', path: '/curriculum' },
    { icon: <Settings size={18} />, label: 'Settings', path: '/settings' },
  ];

  return (
    <aside className="w-64 bg-card border-r border-border flex flex-col h-screen sticky top-0">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8 px-2">
          <div className="h-8 w-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center font-bold font-mono text-lg">
            Σ
          </div>
          <span className="text-lg font-bold tracking-tight">EduTeX</span>
        </div>

        <nav className="space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors",
                  isActive 
                    ? "bg-primary text-primary-foreground shadow-sm" 
                    : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
                )}
              >
                {item.icon}
                <span>{item.label}</span>
                {isActive && <ChevronRight className="ml-auto w-4 h-4 opacity-50" />}
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-4 border-t border-border">
        <Button variant="ghost" className="w-full justify-start gap-2 text-muted-foreground hover:text-foreground">
          <LogOut size={18} />
          Sign Out
        </Button>
        <div className="mt-4 px-4 text-xs text-muted-foreground text-center">
          <p>v2.5.0 (Beta)</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
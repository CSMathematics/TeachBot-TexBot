import React from 'react';
import { Exam } from '../types';
import LatexRenderer from './LatexRenderer';
import { cn } from '../lib/utils';

interface PdfPreviewProps {
  exam: Exam;
  className?: string;
}

const PdfPreview: React.FC<PdfPreviewProps> = ({ exam, className }) => {
  return (
    <div className={cn("mx-auto bg-white text-black shadow-2xl p-12 min-h-[1123px] w-[794px] origin-top transform scale-[0.6] sm:scale-[0.7] md:scale-[0.8] lg:scale-[0.9] xl:scale-100 transition-transform duration-300", className)}>
      {/* Header */}
      <div className="text-center border-b-2 border-black pb-4 mb-8">
        <h1 className="text-3xl font-bold font-serif mb-2 tracking-wide">{exam.title}</h1>
        <div className="flex justify-between text-sm font-serif italic mt-4 px-4">
          <span>{exam.subject}</span>
          <span>{exam.gradeLevel}</span>
          <span>Time: {exam.durationMinutes} min</span>
        </div>
      </div>

      {/* Instructions */}
      <div className="mb-8 text-sm font-serif italic text-gray-600 px-2">
        <p>Instructions: Answer all questions. Show your work clearly for full credit.</p>
      </div>

      {/* Questions */}
      <div className="space-y-10">
        {exam.questions.map((q, idx) => (
          <div key={q.id} className="relative group break-inside-avoid">
             <div className="flex gap-4">
               <span className="font-bold font-serif text-lg">{idx + 1}.</span>
               <div className="flex-1">
                 <div className="text-lg leading-relaxed mb-4 font-serif">
                   <LatexRenderer latex={q.content} />
                 </div>
                 <div className="flex justify-end">
                   <span className="text-sm font-serif italic border border-black rounded px-2 py-0.5">
                     {q.points} points
                   </span>
                 </div>
               </div>
             </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="absolute bottom-12 left-0 w-full text-center text-xs font-serif text-gray-400">
        Generated via EduTeX AI • Exam ID: {exam.id.split('-')[0]}
      </div>
    </div>
  );
};

export default PdfPreview;
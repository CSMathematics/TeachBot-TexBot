import React, { useEffect, useRef } from 'react';

interface LatexRendererProps {
  latex: string;
  block?: boolean;
  className?: string;
}

declare global {
  interface Window {
    katex: any;
  }
}

const LatexRenderer: React.FC<LatexRendererProps> = ({ latex, block = false, className = '' }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current && window.katex) {
      try {
        window.katex.render(latex, containerRef.current, {
          throwOnError: false,
          displayMode: block,
          output: 'html', // Render to HTML for accessibility
        });
      } catch (error) {
        console.error('KaTeX rendering error:', error);
        containerRef.current.innerText = latex; // Fallback
      }
    }
  }, [latex, block]);

  return <div ref={containerRef} className={`${block ? 'my-2' : 'inline'} ${className}`} />;
};

export default LatexRenderer;
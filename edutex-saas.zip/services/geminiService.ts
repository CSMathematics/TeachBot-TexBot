import { GoogleGenAI, Type } from "@google/genai";
import { Exam, GenerationParams } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateExam = async (params: GenerationParams): Promise<Exam> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please provide a valid API key.");
  }

  // Use gemini-3-pro-preview for complex STEM tasks as per guidelines
  const modelId = 'gemini-3-pro-preview'; 

  const prompt = `
    Act as EduTeX, an advanced AI system for generating Math and Physics exams in LaTeX.
    
    You are composed of 4 agents:
    1. Curriculum Architect: Structures the exam based on grade ${params.gradeLevel} and topic "${params.topic}".
    2. Math Generator: Creates unique problems.
    3. Solver & Validator: Solves them to ensure correctness.
    4. LaTeX Typesetter: Formats everything in clean LaTeX.

    Generate a JSON response representing a full exam with ${params.questionCount} questions.
    Difficulty Level: ${params.difficulty} (on a scale of 1-5, where 5 is Olympiad level).
    
    The response MUST strictly follow this schema:
    {
      "title": "Exam Title",
      "subject": "Math or Physics",
      "gradeLevel": "${params.gradeLevel}",
      "durationMinutes": 60,
      "difficulty": 75,
      "questions": [
        {
          "id": "q1",
          "content": "Latex string of the question (do not include \\begin{document} wrappers, just the math)",
          "solution": "Latex string of the solution",
          "difficulty": "Medium",
          "points": 10,
          "type": "Calculus",
          "tags": ["Derivatives", "Chain Rule"]
        }
      ]
    }

    Ensure LaTeX is valid (escape backslashes properly in JSON).
    Use 'align*' for multi-line equations.
    Do not add markdown formatting like \`\`\`json or \`\`\` around the response.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        // Using a predefined schema helps ensure the JSON is parseable and strictly typed
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            subject: { type: Type.STRING },
            gradeLevel: { type: Type.STRING },
            durationMinutes: { type: Type.INTEGER },
            difficulty: { type: Type.INTEGER },
            questions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  content: { type: Type.STRING },
                  solution: { type: Type.STRING },
                  difficulty: { type: Type.STRING, enum: ['Easy', 'Medium', 'Hard', 'Olympiad'] },
                  points: { type: Type.INTEGER },
                  type: { type: Type.STRING },
                  tags: { type: Type.ARRAY, items: { type: Type.STRING } }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    const parsedData = JSON.parse(text);
    
    // Add a generated ID and timestamp
    return {
      ...parsedData,
      id: crypto.randomUUID(),
      createdAt: new Date().toISOString(),
    } as Exam;

  } catch (error) {
    console.error("Error generating exam:", error);
    throw error;
  }
};

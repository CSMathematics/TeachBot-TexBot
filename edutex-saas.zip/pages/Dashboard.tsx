import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';
import { Clock, BookOpen, Users, TrendingUp, Plus, ArrowUpRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, Button } from '../components/ui';

const data = [
  { name: 'Mon', exams: 4 },
  { name: 'Tue', exams: 3 },
  { name: 'Wed', exams: 7 },
  { name: 'Thu', exams: 5 },
  { name: 'Fri', exams: 9 },
  { name: 'Sat', exams: 2 },
  { name: 'Sun', exams: 1 },
];

const coverageData = [
  { subject: 'Algebra', coverage: 85 },
  { subject: 'Geometry', coverage: 65 },
  { subject: 'Calculus', coverage: 40 },
  { subject: 'Stats', coverage: 90 },
  { subject: 'Physics', coverage: 30 },
];

const Dashboard: React.FC = () => {
  return (
    <div className="p-8 max-w-[1600px] mx-auto space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Overview of your generated content and student metrics.</p>
        </div>
        <Link to="/create">
          <Button size="lg" className="gap-2 shadow-lg shadow-primary/20">
            <Plus size={18} />
            Create Exam
          </Button>
        </Link>
      </header>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: <BookOpen className="w-4 h-4 text-muted-foreground" />, label: 'Total Exams', value: '124', trend: '+12%', sub: 'from last month' },
          { icon: <Users className="w-4 h-4 text-muted-foreground" />, label: 'Active Students', value: '840', trend: '+5%', sub: 'new enrollments' },
          { icon: <Clock className="w-4 h-4 text-muted-foreground" />, label: 'Time Saved', value: '42.5h', trend: '+18%', sub: 'automation gained' },
          { icon: <TrendingUp className="w-4 h-4 text-muted-foreground" />, label: 'Avg. Score', value: '76%', trend: '+3%', sub: 'class performance' },
        ].map((stat, idx) => (
          <Card key={idx}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">
                {stat.label}
              </CardTitle>
              {stat.icon}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500 font-medium inline-flex items-center">
                  {stat.trend} <ArrowUpRight className="w-3 h-3 ml-0.5" />
                </span> {stat.sub}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-7 gap-6">
        {/* Main Chart */}
        <Card className="lg:col-span-4">
          <CardHeader>
            <CardTitle>Generation Activity</CardTitle>
            <CardDescription>Exams created over the last 7 days</CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <defs>
                    <linearGradient id="colorExams" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis 
                    dataKey="name" 
                    stroke="#888888" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="#888888" 
                    fontSize={12} 
                    tickLine={false} 
                    axisLine={false} 
                    tickFormatter={(value) => `${value}`} 
                  />
                  <CartesianGrid vertical={false} strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <Tooltip 
                    contentStyle={{ borderRadius: '6px', border: '1px solid hsl(var(--border))', background: 'hsl(var(--background))' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="exams" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2} 
                    fillOpacity={1} 
                    fill="url(#colorExams)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Recent Coverage */}
        <Card className="lg:col-span-3">
          <CardHeader>
            <CardTitle>Topic Coverage</CardTitle>
            <CardDescription>Curriculum progress by topic</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {coverageData.map((item) => (
                <div key={item.subject} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{item.subject}</span>
                    <span className="text-muted-foreground">{item.coverage}%</span>
                  </div>
                  <div className="h-2 w-full rounded-full bg-secondary overflow-hidden">
                    <div 
                      className="h-full bg-primary transition-all duration-1000 ease-out" 
                      style={{ width: `${item.coverage}%` }} 
                    />
                  </div>
                </div>
              ))}
            </div>
            
            <div className="mt-8 rounded-md bg-yellow-500/10 p-4 border border-yellow-500/20">
               <div className="flex items-start gap-2">
                 <div className="mt-0.5 w-2 h-2 rounded-full bg-yellow-500 shrink-0" />
                 <div>
                   <h4 className="text-sm font-semibold text-yellow-600 dark:text-yellow-500">Curriculum Alert</h4>
                   <p className="text-xs text-muted-foreground mt-1">
                     Physics unit is 15% behind schedule. Recommended: Generate a remedial quiz for "Kinematics".
                   </p>
                 </div>
               </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
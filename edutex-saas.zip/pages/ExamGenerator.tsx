import React, { useState } from 'react';
import { generateExam } from '../services/geminiService';
import { Exam, Agent, AgentStatus } from '../types';
import AgentCard from '../components/AgentCard';
import { Save, Download, ChevronLeft, RefreshCw, Wand2, Copy, Check } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button, Input, Select, Label, Card, CardHeader, CardTitle, CardContent, Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui';
import PdfPreview from '../components/PdfPreview';
import { cn } from '../lib/utils';

const ExamGenerator: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [exam, setExam] = useState<Exam | null>(null);
  const [activeTab, setActiveTab] = useState('preview');
  
  // Params State
  const [topic, setTopic] = useState('Derivatives and Slope Fields');
  const [grade, setGrade] = useState('12th Grade AP Calculus');
  const [difficulty, setDifficulty] = useState(3);
  const [questionCount, setQuestionCount] = useState(3);

  // Agent State
  const [agents, setAgents] = useState<Agent[]>([
    { id: 'architect', name: 'Curriculum Architect', role: 'Designing Structure', description: 'Analyzing requirements', status: AgentStatus.IDLE, icon: 'Brain' },
    { id: 'generator', name: 'Math Generator', role: 'Creating Problems', description: 'Generating equations', status: AgentStatus.IDLE, icon: 'Bot' },
    { id: 'validator', name: 'Solver Agent', role: 'Verifying Answers', description: 'Checking logic', status: AgentStatus.IDLE, icon: 'CheckCircle' },
    { id: 'typesetter', name: 'Typesetter', role: 'Formatting LaTeX', description: 'Compiling document', status: AgentStatus.IDLE, icon: 'FileText' },
  ]);

  const simulateAgentWorkflow = async () => {
    const wait = (ms: number) => new Promise(res => setTimeout(res, ms));
    setAgents(prev => prev.map(a => ({ ...a, status: AgentStatus.IDLE })));
    setLoading(true);
    setExam(null); 

    try {
      setAgents(prev => prev.map(a => a.id === 'architect' ? { ...a, status: AgentStatus.WORKING } : a));
      await wait(800);
      setAgents(prev => prev.map(a => a.id === 'architect' ? { ...a, status: AgentStatus.COMPLETED } : a));

      setAgents(prev => prev.map(a => a.id === 'generator' ? { ...a, status: AgentStatus.WORKING } : a));
      const generatedExam = await generateExam({
        topic,
        gradeLevel: grade,
        difficulty,
        questionCount,
        includeSolutions: true
      });
      setAgents(prev => prev.map(a => a.id === 'generator' ? { ...a, status: AgentStatus.COMPLETED } : a));

      setAgents(prev => prev.map(a => a.id === 'validator' ? { ...a, status: AgentStatus.WORKING } : a));
      await wait(600);
      setAgents(prev => prev.map(a => a.id === 'validator' ? { ...a, status: AgentStatus.COMPLETED } : a));

      setAgents(prev => prev.map(a => a.id === 'typesetter' ? { ...a, status: AgentStatus.WORKING } : a));
      await wait(600);
      setAgents(prev => prev.map(a => a.id === 'typesetter' ? { ...a, status: AgentStatus.COMPLETED } : a));

      setExam(generatedExam);
    } catch (error) {
      console.error(error);
      setAgents(prev => prev.map(a => ({ ...a, status: AgentStatus.ERROR })));
      alert("Failed to generate exam.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground">
      {/* Sidebar: Configuration */}
      <div className="w-[400px] border-r border-border bg-background flex flex-col z-10 shadow-xl">
        <div className="p-4 border-b border-border flex items-center gap-2">
           <Link to="/">
             <Button variant="ghost" size="icon" className="h-8 w-8">
               <ChevronLeft className="h-4 w-4" />
             </Button>
           </Link>
           <h2 className="font-semibold text-lg">Exam Configuration</h2>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
           <div className="space-y-4">
             <div className="space-y-2">
               <Label>Topic</Label>
               <Input 
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g. Linear Algebra"
               />
             </div>
             
             <div className="space-y-2">
               <Label>Grade Level</Label>
               <Select value={grade} onChange={(e) => setGrade(e.target.value)}>
                 <option>10th Grade Geometry</option>
                 <option>11th Grade Algebra II</option>
                 <option>12th Grade Pre-Calculus</option>
                 <option>12th Grade AP Calculus</option>
                 <option>University Physics I</option>
               </Select>
             </div>

             <div className="space-y-4 pt-2">
               <div className="flex justify-between items-center">
                 <Label>Difficulty</Label>
                 <span className="text-xs font-mono text-muted-foreground bg-secondary px-2 py-0.5 rounded">
                   {difficulty === 5 ? 'OLYMPIAD' : difficulty >= 4 ? 'ADVANCED' : difficulty === 3 ? 'STANDARD' : 'BASIC'}
                 </span>
               </div>
               <input 
                 type="range" 
                 min="1" 
                 max="5" 
                 value={difficulty}
                 onChange={(e) => setDifficulty(Number(e.target.value))}
                 className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
               />
             </div>

             <div className="space-y-2">
                <Label>Questions ({questionCount})</Label>
                <Input 
                  type="number"
                  min="1"
                  max="10"
                  value={questionCount}
                  onChange={(e) => setQuestionCount(Number(e.target.value))}
                />
             </div>
           </div>

           <div className="space-y-2">
             <Label className="text-muted-foreground text-xs uppercase tracking-wider font-semibold">AI Agents</Label>
             <div className="grid gap-2">
               {agents.map(agent => <AgentCard key={agent.id} agent={agent} />)}
             </div>
           </div>
        </div>

        <div className="p-4 border-t border-border bg-background/50 backdrop-blur">
          <Button 
            onClick={simulateAgentWorkflow}
            disabled={loading}
            className="w-full gap-2 h-12 text-base shadow-lg shadow-primary/25"
          >
            {loading ? <RefreshCw className="animate-spin h-4 w-4" /> : <Wand2 className="h-4 w-4" />}
            {loading ? "Generating..." : "Generate Exam"}
          </Button>
        </div>
      </div>

      {/* Main Content: Preview */}
      <div className="flex-1 flex flex-col bg-secondary/30">
        <div className="h-14 border-b border-border bg-background flex items-center justify-between px-6">
           <Tabs value={activeTab} className="w-[200px]">
             <div className="flex bg-muted rounded-md p-1">
               <button 
                 onClick={() => setActiveTab('preview')}
                 className={cn("flex-1 text-sm font-medium px-3 py-1 rounded-sm transition-all", activeTab === 'preview' ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground")}
               >
                 Preview
               </button>
               <button 
                 onClick={() => setActiveTab('code')}
                 className={cn("flex-1 text-sm font-medium px-3 py-1 rounded-sm transition-all", activeTab === 'code' ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground")}
               >
                 LaTeX
               </button>
             </div>
           </Tabs>

           <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-2" disabled={!exam}>
                <Save className="h-4 w-4" /> Save
              </Button>
              <Button size="sm" className="gap-2" disabled={!exam}>
                <Download className="h-4 w-4" /> PDF
              </Button>
           </div>
        </div>

        <div className="flex-1 overflow-auto p-8 flex justify-center">
           {!exam && !loading && (
             <div className="flex flex-col items-center justify-center h-full text-muted-foreground max-w-md text-center">
               <div className="w-16 h-16 rounded-2xl bg-secondary flex items-center justify-center mb-4">
                 <Wand2 className="h-8 w-8 opacity-50" />
               </div>
               <h3 className="text-lg font-semibold text-foreground">Ready to Create</h3>
               <p className="text-sm mt-2">Configure the parameters on the left and let our multi-agent system craft your exam.</p>
             </div>
           )}

           {loading && !exam && (
             <div className="flex flex-col items-center justify-center h-full space-y-4">
               <div className="relative w-20 h-20">
                  <div className="absolute inset-0 rounded-full border-4 border-secondary"></div>
                  <div className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
               </div>
               <p className="text-muted-foreground font-medium animate-pulse">Constructing Exam...</p>
             </div>
           )}

           {exam && activeTab === 'preview' && (
             <PdfPreview exam={exam} />
           )}

           {exam && activeTab === 'code' && (
             <Card className="w-full max-w-4xl h-fit font-mono text-sm">
               <CardHeader className="flex flex-row items-center justify-between py-4 border-b">
                 <CardTitle className="text-base">LaTeX Source</CardTitle>
                 <Button variant="ghost" size="sm" className="h-8 gap-2">
                   <Copy className="h-3 w-3" /> Copy
                 </Button>
               </CardHeader>
               <CardContent className="p-0 bg-[#282c34]">
                 <pre className="p-6 overflow-x-auto text-[#abb2bf] leading-relaxed">
{`\\documentclass{article}
\\usepackage{amsmath}
\\usepackage{amssymb}
\\usepackage{geometry}

\\title{${exam.title}}
\\date{\\today}

\\begin{document}
\\maketitle

\\section*{${exam.subject} - ${exam.gradeLevel}}
Duration: ${exam.durationMinutes} minutes

\\begin{enumerate}
${exam.questions.map(q => `
    \\item (${q.points} pts)
    ${q.content}
    
    % Solution:
    % ${q.solution}
`).join('\n')}
\\end{enumerate}

\\end{document}`}
                 </pre>
               </CardContent>
             </Card>
           )}
        </div>
      </div>
    </div>
  );
};

export default ExamGenerator;
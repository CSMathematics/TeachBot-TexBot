import React from 'react';
import { HashRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import ExamGenerator from './pages/ExamGenerator';
import { cn } from './lib/utils';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const location = useLocation();
  const isGenerator = location.pathname === '/create';

  if (isGenerator) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen bg-background font-sans text-foreground">
      <Sidebar />
      <main className="flex-1 overflow-y-auto">
        {children}
      </main>
    </div>
  );
};

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/create" element={<ExamGenerator />} />
          {/* Placeholders for routes not implemented in this demo */}
          <Route path="/library" element={<div className="p-8">Library (Coming Soon)</div>} />
          <Route path="/curriculum" element={<div className="p-8">Curriculum (Coming Soon)</div>} />
          <Route path="/settings" element={<div className="p-8">Settings (Coming Soon)</div>} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;